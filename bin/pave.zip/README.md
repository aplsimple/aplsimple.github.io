# pave

The pave is sort of wrapper around the grid and pack Tcl/Tk geometry managers.

Details:

https://aplsimple.github.io/en/tcl/pave
