# e_menu

e_menu provides a menu system bound to an edit session.

A text editor with plugin or context facilities allows to use e_menu as "a plugin of plugins" that raises a whole environment of commands & menus around the editor.

Details:

  https://aplsimple.github.io/en/tcl/e_menu
