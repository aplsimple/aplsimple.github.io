#! /bin/bash
echo "$@"
echo ""
eval "$@"
echo ""
echo "Press return to continue"
read
